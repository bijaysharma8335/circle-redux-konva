import React from 'react';
import Drawingpage from './drawingpage';
// import Counter from './circlecomp';
const App=()=>{
  return(<>
 
    <Drawingpage/>
    </>
  );
}
export default App;


